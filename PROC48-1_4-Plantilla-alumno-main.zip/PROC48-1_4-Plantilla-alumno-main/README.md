# PROC48-1_4-Plantilla-alumno
Campo de tiro etapa II.  

## Texto en inglés: SHOOTING-RANGE-II-template
